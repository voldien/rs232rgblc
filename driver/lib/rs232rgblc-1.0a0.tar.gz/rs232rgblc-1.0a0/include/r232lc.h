/**
    r232 LED controller library interface.
    Copyright (C) 2017  Valdemar Lindberg

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/
#ifndef _R232_LC_H_
#define _R232_LC_H_ 1
#include"r232lcdef.h"
#include<stdio.h>
#include<stdlib.h>

/**
 *
 */
typedef struct rs232lc_t{
	int fd;			/*	file descriptor with */
	unsigned int state;	/*	*/
	unsigned int pwm;	/*	*/
	unsigned int anim;	/*	*/
	unsigned int baud;	/*	buad rate mode.	*/
}RS232LC;

/**
 *	Create RGB value.
 */
#define R232LC_RGB(r,g,b) (((r & 0xff) << 0) | ((g & 0xff) << 8) | ((b & 0xff) << 16) )

/**
 *	States.
 */
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/
#define STATE_ANIM 0x8	/*	*/

/**
 *	Baud rate.
 */
#define BAUD1200	0x0	/*	1200 bps.	*/
#define BAUD2400	0x1	/*	2400 bps.	*/
#define BAUD4800	0x2	/*	4800 bps.	*/
#define BAUD9600	0x3	/*	9600 bps.	*/
#define BAUD19200	0x4	/*	19200 bps.	*/
#define BAUD38400	0x5	/*	38400 bps.	*/
#define BAUD57600	0x6	/*	57600 bps.	*/
#define BAUD115200	0x7	/*	115200 bps.	*/

/**
 *	Buad rates.
 */
const uint32_t baudrates[] = {
		110, 300, 600, 1200, 2400, 4800, 9600,
		14400, 19200, 38400, 57600, 115200, 128000, 256000
};


#ifdef __cplusplus
extern "C"{
#endif

/**
 *	Initialize.
 *
 *	@Return non zero if successfully.
 */
extern R232LCDECLSPEC int rs232lc_init(RS232LC* state, int fd);

/**/
extern R232LCDECLSPEC int rs232lc_close(RS232LC* state);

/**
 *	Set/Get PWM for the LED intensitiy.
 */
extern R232LCDECLSPEC void rs232lc_set_pwm(RS232LC* state, uint8_t pwm);
extern R232LCDECLSPEC uint8_t rs232lc_get_pwm(RS232LC* state);

/**
 *	Set/Get baud rate.
 */
extern R232LCDECLSPEC int rs232lc_set_baud(RS232LC* state, uint8_t baud);
extern R232LCDECLSPEC uint8_t rs232lc_get_baud(RS232LC* state);

/**
 *	Write rgb.
 */
extern R232LCDECLSPEC void rs232lc_set_rgb(RS232LC* state, uint32_t rgb);

/**
 *	Set/Get animation.
 */
extern R232LCDECLSPEC void rs232lc_set_anim(RS232LC* state, unsigned int anim);
extern R232LCDECLSPEC int rs232lc_get_anim(RS232LC* state);

/**
 *	Set/Get bitwise state.
 */
extern R232LCDECLSPEC void r232lc_set_state(RS232LC* state, unsigned int pwm);
extern R232LCDECLSPEC void r232lc_get_state(RS232LC* state, void* st);

/**
 *	Get version of the firmware on the r232 LED controller.
 */
extern R232LCDECLSPEC void rs232lc_get_version(const RS232LC* state, char* pversion);


#ifdef __cplusplus
};
#endif

#endif 
